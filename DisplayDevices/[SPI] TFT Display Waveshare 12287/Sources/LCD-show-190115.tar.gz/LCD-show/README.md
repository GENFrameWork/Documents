# 型号:2.8inch RPi LCD (A)

相关介绍：

http://www.waveshare.net/shop/2.8inch-RPi-LCD-A.htm

https://www.waveshare.com/2.8inch-rpi-lcd-a.htm

WIKI链接：

http://www.waveshare.net/wiki/2.8inch_RPi_LCD_(A)

https://www.waveshare.com/wiki/2.8inch_RPi_LCD_(A)

执行命令：

sudo ./LCD28-show

# 型号:3.2inch RPi LCD (B)

相关介绍：

http://www.waveshare.net/shop/3.2inch-RPi-LCD-B.htm

https://www.waveshare.com/3.2inch-rpi-lcd-b.htm

WIKI链接：

http://www.waveshare.net/wiki/3.2inch_RPi_LCD_(B)

https://www.waveshare.com/wiki/3.2inch_RPi_LCD_(B)

执行命令：

sudo ./LCD32-show

# 型号:3.5inch RPi LCD (C)

相关介绍：

http://www.waveshare.net/shop/3.5inch-RPi-LCD-C.htm

https://www.waveshare.com/3.5inch-rpi-lcd-c.htm

WIKI链接：

http://www.waveshare.net/wiki/3.5inch_RPi_LCD_(C)

https://www.waveshare.com/wiki/3.5inch_RPi_LCD_(C)

执行命令：

sudo ./LCD35C-show
