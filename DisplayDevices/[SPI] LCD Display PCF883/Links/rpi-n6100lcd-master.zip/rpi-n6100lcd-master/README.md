# rpi-n6100lcd
Raspberry Pi: Interfacing Nokia 6100 LCD
