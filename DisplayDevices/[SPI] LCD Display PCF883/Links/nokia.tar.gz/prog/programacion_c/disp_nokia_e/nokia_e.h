 
#define BL	0
#define RST	1
#define	CS	2
#define	SDIO	3
#define	CLK	4

#define ON	1
#define OFF	0

// Font sizes
#define P 0
#define M 1
#define G 2
 
// LCD Dimension Definitions

#define ROW_LENGTH	132
#define COL_HEIGHT	132
#define ENDPAGE     132
#define ENDCOL      132

// Basic Colors

#define BLACK		0x000
#define NAVY 		0x008
#define BLUE		0x00F
#define TEAL 		0x088
#define EMERALD		0x0C5
#define	GREEN		0x0F0
#define CYAN		0x0FF
#define SLATE 		0x244
#define INDIGO  	0x408
#define TURQUOISE	0x4ED
#define OLIVE 		0x682
#define MAROON 		0x800
#define PURPLE 		0x808
#define GRAY 		0x888
#define SKYBLUE		0x8CE
#define BROWN		0xB22
#define CRIMSON 	0xD13
#define ORCHID 		0xD7D
#define RED			0xF00
#define MAGENTA		0xF0F
#define ORANGE 		0xF40
#define PINK		0xF6A
#define CORAL 		0xF75
#define SALMON 		0xF87
#define GOLD 		0xFD0
#define YELLOW		0xFF0
#define WHITE		0xFFF

// Epson S1D15G10 Command Set

#define DISON		0xaf
#define DISOFF		0xae
#define DISNOR		0xa6
#define DISINV		0xa7
#define COMSCN		0xbb
#define DISCTL		0xca
#define SLPIN		0x95
#define SLPOUT		0x94
#define PASET		0x75
#define CASET		0x15
#define DATCTL		0xbc
#define RGBSET8		0xce
#define RAMWR		0x5c
#define RAMRD		0x5d
#define PTLIN		0xa8
#define PTLOUT		0xa9
#define RMWIN		0xe0
#define RMWOUT		0xee
#define ASCSET		0xaa
#define SCSTART		0xab
#define OSCON		0xd1
#define OSCOFF		0xd2
#define PWRCTR		0x20
#define VOLCTR		0x81
#define VOLUP		0xd6
#define VOLDOWN		0xd7
#define TMPGRD		0x82
#define EPCTIN		0xcd
#define EPCOUT		0xcc
#define EPMWR		0xfc
#define EPMRD		0xfd
#define EPSRRD1		0x7c
#define EPSRRD2		0x7d
#define NOP			0x25
