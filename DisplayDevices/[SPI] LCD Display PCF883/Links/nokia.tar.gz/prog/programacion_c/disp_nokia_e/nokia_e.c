//*******************CONTROLADOR EPSON*******************************
//
//	rasp_pin		wiringPi		lcd
//----------------------------------------
//	1								3.3V
//	6								GND
//	11				0				BL+(backligth)
//	12				1				RST	(reset)
//	13				2				CS (chip select)
//	15				3				SDIO	(data in)
//	16				4				SCK	(clock)

#include "nokia_e.h"
#include <wiringPi.h>
#include <stdio.h>
#include "fonts.h"
#include "alex.h"
#include "laura.h"


//iniciliza el hardware de e/s:
int	init_io(void){
	//inicializar wiringPi:
	if(wiringPiSetup()==-1){
		printf("Error inicializando wiringPi...\n");
		return 0;
	}
	//configurar salidas:
	pinMode (BL,OUTPUT);
	pinMode (RST,OUTPUT);
	pinMode (CS,OUTPUT);
	pinMode (SDIO,OUTPUT);
	pinMode (CLK,OUTPUT);
	//establecer estados iniciales:
	digitalWrite(RST,1);
	digitalWrite(CS,1);
	digitalWrite(SDIO,0);
	digitalWrite(CLK,0);
	digitalWrite(BL,0);
	
	return 1;
}

//resetea el display:
void disp_res(void){
	digitalWrite(RST,0); 
	delay(100);
	digitalWrite(RST,1);
}


//enciende o apaga el backligth
void backligth(int modo){
	if(modo){
		digitalWrite(BL,1);}
	else{
		digitalWrite(BL,0);}
	}
	
//envia un dato al display:
void disp_send_dat(int dato){

	digitalWrite(CS,0);//CS bajo
	
	digitalWrite(SDIO,1);//modo datos: bit 9 a 1
	
	digitalWrite(CLK,1);//pulso reloj
	digitalWrite(CLK,0);
	
	if((dato&128)==128){digitalWrite(SDIO,1);}//bit 7
	else{digitalWrite(SDIO,0);}
	digitalWrite(CLK,1);//pulso reloj
	digitalWrite(CLK,0);
	
	if((dato&64)==64){digitalWrite(SDIO,1);}//bit 6
	else{digitalWrite(SDIO,0);}
	digitalWrite(CLK,1);//pulso reloj
	digitalWrite(CLK,0);
	
	if((dato&32)==32){digitalWrite(SDIO,1);}//bit 5
	else{digitalWrite(SDIO,0);}
	digitalWrite(CLK,1);//pulso reloj
	digitalWrite(CLK,0);
	
	if((dato&16)==16){digitalWrite(SDIO,1);}//bit 4
	else{digitalWrite(SDIO,0);}
	digitalWrite(CLK,1);//pulso reloj
	digitalWrite(CLK,0);
	
	if((dato&8)==8){digitalWrite(SDIO,1);}//bit 3
	else{digitalWrite(SDIO,0);}
	digitalWrite(CLK,1);//pulso reloj
	digitalWrite(CLK,0);
	
	if((dato&4)==4){digitalWrite(SDIO,1);}//bit 2
	else{digitalWrite(SDIO,0);}
	digitalWrite(CLK,1);//pulso reloj
	digitalWrite(CLK,0);
	
	if((dato&2)==2){digitalWrite(SDIO,1);}//bit 1
	else{digitalWrite(SDIO,0);}
	digitalWrite(CLK,1);//pulso reloj
	digitalWrite(CLK,0);
	
	if((dato&1)==1){digitalWrite(SDIO,1);}//bit 0
	else{digitalWrite(SDIO,0);}
	digitalWrite(CLK,1);//pulso reloj
	digitalWrite(CLK,0);
		
	digitalWrite(SDIO,0);//datos bajo
	digitalWrite(CS,1);	//CS alto
	}
	
//envia un comando al display:
void disp_send_cmd(int dato){
	digitalWrite(CS,0);//CS bajo
	
	digitalWrite(SDIO,0);//modo comandos: bit 9 a 0
	
	digitalWrite(CLK,1);//pulso reloj
	digitalWrite(CLK,0);
	
	if((dato&128)==128){digitalWrite(SDIO,1);}//bit 7
	else{digitalWrite(SDIO,0);}
	digitalWrite(CLK,1);//pulso reloj
	digitalWrite(CLK,0);
	
	if((dato&64)==64){digitalWrite(SDIO,1);}//bit 6
	else{digitalWrite(SDIO,0);}
	digitalWrite(CLK,1);//pulso reloj
	digitalWrite(CLK,0);
	
	if((dato&32)==32){digitalWrite(SDIO,1);}//bit 5
	else{digitalWrite(SDIO,0);}
	digitalWrite(CLK,1);//pulso reloj
	digitalWrite(CLK,0);
	
	if((dato&16)==16){digitalWrite(SDIO,1);}//bit 4
	else{digitalWrite(SDIO,0);}
	digitalWrite(CLK,1);//pulso reloj
	digitalWrite(CLK,0);
	
	if((dato&8)==8){digitalWrite(SDIO,1);}//bit 3
	else{digitalWrite(SDIO,0);}
	digitalWrite(CLK,1);//pulso reloj
	digitalWrite(CLK,0);
	
	if((dato&4)==4){digitalWrite(SDIO,1);}//bit 2
	else{digitalWrite(SDIO,0);}
	digitalWrite(CLK,1);//pulso reloj
	digitalWrite(CLK,0);
	
	if((dato&2)==2){digitalWrite(SDIO,1);}//bit 1
	else{digitalWrite(SDIO,0);}
	digitalWrite(CLK,1);//pulso reloj
	digitalWrite(CLK,0);
	
	if((dato&1)==1){digitalWrite(SDIO,1);}//bit 0
	else{digitalWrite(SDIO,0);}
	digitalWrite(CLK,1);//pulso reloj
	digitalWrite(CLK,0);
		
	digitalWrite(SDIO,0);//datos bajo
	digitalWrite(CS,1);	//CS alto
	}	


void disp_clear(int color){
	int i,b1,b2,b3;
	disp_send_cmd(PASET);	// page start/end ram
	disp_send_dat(0x00);
	disp_send_dat(0x84);
	
	disp_send_cmd(CASET);	// column start/end ram
	disp_send_dat(0x00);
	disp_send_dat(0x84);
	
	disp_send_cmd(RAMWR);	            // RAM write
	b1=(color>>4)&0x00FF;
	b2=((color&0x0F)<<4)|(color>>8);
	b3=color&0x0FF;// nop(EPSON)
	for(i=0; i < (132*132)/2; i++)
	{
		disp_send_dat(b1);
		disp_send_dat(b2);
		disp_send_dat(b3);  	
	}	
}

//inicializa el display:
void disp_init(void){
	backligth(ON);//encendemos el back ligth
	disp_res();//reset por hard
	disp_send_cmd(DISCTL);
	disp_send_dat(0x03); // 2 divisions, Field swithcing period 
	disp_send_dat(0X20); // 132 lines to be display              
	disp_send_dat(0X0C); // Inversely hightlighted lines - 1       
	disp_send_dat(0X00);
	
	disp_send_cmd(COMSCN); // comscn
	disp_send_dat(0x01);
	
	disp_send_cmd(OSCON); // oscon
	disp_send_cmd(SLPOUT); // sleep out
	
	disp_send_cmd(VOLCTR); // electronic volume, this is kinda contrast/brightness
	disp_send_dat(0x26); // this might be different for individual LCDs
	disp_send_dat(0x03);
	
	disp_send_cmd(PWRCTR); // power ctrl
	disp_send_dat(0x0F); // everything on, no external reference resistors
	delay(100);
	
	disp_send_cmd(DISINV); // display mode	
	disp_send_cmd(DATCTL);//Data Control
	disp_send_dat(0x02); //0x00 for normal, 0x01 for flip vertical, 0x03 horizontal and vertical flip.
	disp_send_dat(0x02); //0x00 for low color grainy, 0x01 for red lines above/below, 0x02 for color, >0x02 for extra blueness
	disp_send_dat(0xFF); //does nothing
	
	disp_send_cmd(NOP);
	disp_send_cmd(DISON); // display on
	
	disp_clear(WHITE);
}

void disp_point(int x,int y,int color){
	y = (COL_HEIGHT - 1) - y;
	x = (ROW_LENGTH - 1) - x;
	
	disp_send_cmd(PASET);	// page start/end ram
	disp_send_dat(x);
	disp_send_dat(ENDPAGE);
	
	disp_send_cmd(CASET);	// column start/end ram
	disp_send_dat(y);
	disp_send_dat(ENDCOL);
	
	disp_send_cmd(RAMWR);	            // RAM write
	disp_send_dat((color>>4)&0x00FF);
	disp_send_dat(((color&0x0F)<<4)|(color>>8));
	disp_send_dat(color&0x0FF);		// nop(EPSON)		
}

void disp_line(int x0,int y0,int x1,int y1,int color){
	int dy = y1 - y0;
	int dx = x1 - x0;
	int stepx, stepy;
	if (dy < 0) { dy = -dy; stepy = -1; } else { stepy = 1; }
	if (dx < 0) { dx = -dx; stepx = -1; } else { stepx = 1; }
	dy <<= 1; // dy is now 2*dy
	dx <<= 1; // dx is now 2*dx
	disp_point(x0, y0, color);
	if (dx > dy) {
	int fraction = dy - (dx >> 1); // same as 2*dy - dx
	while (x0 != x1) {
	if (fraction >= 0) {
	y0 += stepy;
	fraction -= dx; // same as fraction -= 2*dx
	}
	x0 += stepx;
	fraction += dy; // same as fraction -= 2*dy
	disp_point(x0, y0, color);
	}
	} else {
	int fraction = dx - (dy >> 1);
	while (y0 != y1) {
	if (fraction >= 0) {
	x0 += stepx;
	fraction -= dy;
	}
	y0 += stepy;
	fraction += dx;
	disp_point(x0, y0, color);
	}
	}
}

//dibuja un rectangulo pasando las coordenadas de sus esquinas opuestas,puede ser relleno o no dependiendo
//de la variable FILL, 0=sin relleno, 1=relleno
void disp_rect(int x0,int y0,int x1,int y1,char fill,int color){
	int xmin, xmax, ymin, ymax,b1,b2,b3;
int i;

if (fill) {
	
	xmin = (x0 <= x1) ? x0 : x1;
	xmax = (x0 > x1) ? x0 : x1;
	ymin = (y0 <= y1) ? y0 : y1;
	ymax = (y0 > y1) ? y0 : y1;
	
	disp_send_cmd(PASET);
	disp_send_dat(xmin);
	disp_send_dat(xmax);

	disp_send_cmd(CASET);
	disp_send_dat(ymin);
	disp_send_dat(ymax);
	// WRITE MEMORY
	disp_send_cmd(RAMWR);
	b1=color>>4;
	b2=(color<<8)|(color>>8);
	b3=color<<4;
	// loop on total number of pixels / 2
	for (i = 0; i < ((((xmax - xmin + 1) * (ymax - ymin + 1)) / 2) + 1); i++) {
	// use the color value to output three data bytes covering two pixels
		disp_send_dat(b1);
		disp_send_dat(b2);
		disp_send_dat(b3);
		}
	}
	else{
		disp_line(x0, y0, x1, y0, color);
		disp_line(x0, y1, x1, y1, color);
		disp_line(x0, y0, x0, y1, color);
		disp_line(x1, y0, x1, y1, color);
	}
}

//dibuja un circulo con centro en x0-y0 ,radio r y color especificado
void disp_circle(int x0,int y0,int r,int color){
	int f = 1 - r;
	int ddF_x = 0;
	int ddF_y = -2 * r;
	int x = 0;
	int y = r;
	disp_point(x0, y0 + r, color);
	disp_point(x0, y0 - r, color);
	disp_point(x0 + r, y0, color);
	disp_point(x0 - r, y0, color);
	while(x < y) {
		if (f >= 0) {
		y--;
		ddF_y += 2;
		f += ddF_y;
		}
		x++;
		ddF_x += 2;
		f += ddF_x + 1;
		disp_point(x0 + x, y0 + y, color);
		disp_point(x0 - x, y0 + y, color);
		disp_point(x0 + x, y0 - y, color);
		disp_point(x0 - x, y0 - y, color);
		disp_point(x0 + y, y0 + x, color);
		disp_point(x0 - y, y0 + x, color);
		disp_point(x0 + y, y0 - x, color);
		disp_point(x0 - y, y0 - x, color);
	}
}

//dibuja un caracter en el display
//c:caracter
//x,y:coordenadas
//size:tamaño pude ser P:pequeño, M:mediano, G:grande
//fColor:color primer plano
//bColor:color de fondo
void disp_putchar(char c, int x, int y, int size, int fColor, int bColor) {
	extern const unsigned char FONT6x8[97][8];
	extern const unsigned char FONT8x8[97][8];
	extern const unsigned char FONT8x16[97][16];
	int i,j;
	unsigned int nCols;
	unsigned int nRows;
	unsigned int nBytes;
	unsigned char PixelRow;
	unsigned char Mask;
	unsigned int Word0;
	unsigned int Word1;
	unsigned char *pFont;
	unsigned char *pChar;
	unsigned char *FontTable[] = {(unsigned char *)FONT6x8,
	(unsigned char *)FONT8x8,
	(unsigned char *)FONT8x16};
	
	pFont = (unsigned char *)FontTable[size];
	nCols = *pFont;
	nRows = *(pFont + 1);
	nBytes = *(pFont + 2);

	pChar = pFont + (nBytes * (c - 0x1F)) + nBytes - 1;

	disp_send_cmd(PASET);
	disp_send_dat(x);
	disp_send_dat(x + nRows - 1);

	disp_send_cmd(CASET);
	disp_send_dat(y);
	disp_send_dat(y + nCols - 1);

	disp_send_cmd(RAMWR);

	for (i = nRows - 1; i >= 0; i--) {
		PixelRow = *pChar--;
		Mask = 0x80;
		for (j = 0; j < nCols; j += 2) {
		if ((PixelRow & Mask) == 0)
			Word0 = bColor;
		else
			Word0 = fColor;
		Mask = Mask >> 1;
		if ((PixelRow & Mask) == 0)
			Word1 = bColor;
		else
			Word1 = fColor;
		Mask = Mask >> 1;
		disp_send_dat((Word0 >> 4) & 0xFF);
		disp_send_dat(((Word0 & 0xF) << 4) | ((Word1 >> 8) & 0xF));
		disp_send_dat(Word1 & 0xFF);
		}
	}
	disp_send_cmd(NOP);
}

//dibuja un string en el display:
//*pString:puntero a la cadena de caracteres
//x,y:coordenadas
//size:tamaño pude ser P:pequeño, M:mediano, G:grande
//fColor:color primer plano
//bColor:color de fondo
void disp_putstr(const char *pString, int x, int y, int Size, int fColor, int bColor) {
	
	while (*pString != 0x00) {
		disp_putchar(*pString++, 131-x, 131-y, Size, fColor, bColor);
		if (Size == P)
		y = y + 6;
		else if (Size == M)
		y = y + 8;
		else
		y = y + 8;
		//if (y > 131) break;
	}
}

//dibuja un archivo bmp de 130x130 pixels confeccionado con
//la utilidad BmpToArray.exe
void disp_bmp( char *bmp,long tam) {
	long j; // loop counter
	disp_send_cmd(DATCTL);//Data Control
	disp_send_dat(0x01); //0x00 for normal, 0x01 for flip vertical, 0x03 horizontal and vertical flip.
	disp_send_dat(0x01); //0x00 for low color grainy, 0x01 for red lines above/below, 0x02 for color, >0x02 for extra blueness
	disp_send_dat(0xFF); //does nothing
	// Display OFF
	disp_send_cmd(DISOFF);
	// Column address set (command 0x2A)
	disp_send_cmd(CASET);
	disp_send_dat(0);
	disp_send_dat(131);
	// Page address set (command 0x2B)
	disp_send_cmd(PASET);
	disp_send_dat(0);
	disp_send_dat(131);
	// WRITE MEMORY
	disp_send_cmd(RAMWR);
	for (j = 0; j < tam; j++) {
		disp_send_dat((int)bmp[j]);

}
	disp_send_cmd(DATCTL);//Data Control
	disp_send_dat(0x02); //0x00 for normal, 0x01 for flip vertical, 0x03 horizontal and vertical flip.
	disp_send_dat(0x02); //0x00 for low color grainy, 0x01 for red lines above/below, 0x02 for color, >0x02 for extra blueness
	disp_send_dat(0xFF); //does nothing
	 //Display On
	disp_send_cmd(DISON);
}
//programa de prueba:
int main(void){
	int n;
	char *p;
	long t;
	init_io();
	disp_init();
	
	disp_clear(GREEN);
	for(n=0;n<131;n+=10){
		disp_line(0,n,131,n,BLACK);
		disp_line(n,0,n,131,BLACK);
	}
	delay(5000);
	disp_clear(BLACK);
	for(n=0;n<65;n+=5){
		disp_rect(0+n,0+n,131-n,131-n,0,RED);}
	delay(5000);
	disp_clear(WHITE);
	for(n=0;n<65;n+=4){
		disp_circle(65,65,n,BLUE);}
	delay(3000);
	disp_clear(BLACK);
	disp_putstr("Hola mundo.",35,18,G,RED,BLACK);
	disp_putstr("Hello world.",55,18,G,BLUE,BLACK);
	disp_putstr("Raspberry Pi.",75,18,G,YELLOW,BLACK);
	delay(5000);
	for(n=0;n<2;n++){
	p=alex;
	t=sizeof(alex);
	disp_bmp(p,t);
	delay(3000);
	p=laura;
	t=sizeof(laura);
	disp_bmp(p,t);
	delay(3000);
	}
	backligth(OFF);
	return 0;
}
